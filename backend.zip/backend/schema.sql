-- =========================================================================
-- ESQUEMA DE BASE DE DATOS D1 CLOUDFLARE | VERSIÓN 12 DE ABRIL
-- PROYECTO: Soterrados IoT
-- OBJETIVO: Este archivo define la estructura (tablas y columnas) de la base
-- de datos relacional (SQLite) que vive en los servidores de Cloudflare.
-- =========================================================================

-- ⚠️ ZONA DE PELIGRO: REINICIO DE BASE DE DATOS
-- Las siguientes 4 líneas sirven para "formatear" la base de datos.
-- Al usar 'DROP TABLE IF EXISTS', le decimos a Cloudflare que destruya la tabla 
-- y todos sus datos si es que ya existía, para crearla limpia nuevamente abajo.
--DROP TABLE IF EXISTS containers;
--DROP TABLE IF EXISTS readings;
--DROP TABLE IF EXISTS emptying_events;
DROP TABLE IF EXISTS users;

-- =========================================================================
-- TABLA 1: containers (CONTENEDORES EN VIVO)
-- =========================================================================
-- Esta tabla almacena la información "fija" del contenedor y su ÚLTIMO estado.
-- No guarda historial, solo "cómo está en este exacto segundo".
CREATE TABLE IF NOT EXISTS containers (
    id TEXT PRIMARY KEY,                       -- ID único del contenedor (Ej. BIN-001)
    name TEXT DEFAULT 'Contenedor Desconocido',-- Nombre legible para la web
    lat REAL NOT NULL,                         -- Latitud (REAL significa número con decimales)
    lng REAL NOT NULL,                         -- Longitud (Para ubicarlo en el mapa Leaflet)
    address TEXT DEFAULT 'Dirección no registrada', -- Dirección física agregada por el Admin
    photo_url TEXT,                            -- Enlace (URL) de la fotografía real del contenedor
    current_fill_level REAL DEFAULT 0,         -- Promedio general del 0 al 100%
    current_fill_sec1 REAL DEFAULT 0,          -- Porcentaje exacto del sensor ultrasónico 1
    current_fill_sec2 REAL DEFAULT 0,          -- Porcentaje exacto del sensor ultrasónico 2
    current_fill_sec3 REAL DEFAULT 0,          -- Porcentaje exacto del sensor ultrasónico 3
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP -- Fecha y hora exacta del último envío de datos
);

-- =========================================================================
-- TABLA 2: readings (HISTORIAL DE SENSORES IOT)
-- =========================================================================
-- Esta tabla almacena TODO el tráfico de datos. Si un sensor envía datos cada
-- 5 segundos, aquí se guarda una fila nueva cada 5 segundos. 
-- Es vital para generar las gráficas estadísticas.
CREATE TABLE IF NOT EXISTS readings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,      -- Número de registro automático (1, 2, 3...)
    container_id TEXT NOT NULL,                -- A qué contenedor pertenece este dato (Llave foránea implícita)
    sec1 REAL NOT NULL,                        -- Dato del sensor 1 en ese instante de tiempo
    sec2 REAL NOT NULL,                        -- Dato del sensor 2
    sec3 REAL NOT NULL,                        -- Dato del sensor 3
    average_fill REAL NOT NULL,                -- El promedio de los 3 calculado en el backend
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP -- Cuándo ocurrió exactamente esta lectura
);

-- =========================================================================
-- TABLA 3: emptying_events (EVENTOS DE RECOLECCIÓN DEL CAMIÓN)
-- =========================================================================
-- Registra los momentos en los que el camión vacía el contenedor.
-- Se alimenta matemáticamente cuando el nivel cae drásticamente.
CREATE TABLE IF NOT EXISTS emptying_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    container_id TEXT NOT NULL,                -- El ID del contenedor que fue vaciado
    level_before REAL NOT NULL,                -- % de basura que tenía justo antes de que pase el camión (Ej: 95%)
    level_after REAL NOT NULL,                 -- % de basura que quedó después del vaciado (Ej: 5%)
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================================
-- TABLA 4: users (SISTEMA DE USUARIOS Y ROLES)
-- =========================================================================
-- Guarda las cuentas de Google que inician sesión en la página web.
CREATE TABLE IF NOT EXISTS users (
    email TEXT PRIMARY KEY,                    -- El correo es la llave principal (No puede haber dos iguales)
    name TEXT,                                 -- Nombre extraído de la cuenta de Google
    picture TEXT,                              -- Enlace de la foto de perfil de Google
    role TEXT DEFAULT 'user',                  -- Rol de permisos. 'user' = limitado, 'admin' = total
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 🔑 CREACIÓN DEL SUPER USUARIO (ADMINISTRADOR MAESTRO)
-- Este comando inserta tu cuenta manualmente y te da permisos 'admin' desde el inicio.
-- 'INSERT OR IGNORE' significa que si tu correo ya está en la tabla, no dará error, solo lo omitirá.
INSERT OR IGNORE INTO users (email, name, role) 
VALUES ('iotsoterrados@gmail.com', 'Admin Principal', 'admin');

-- =========================================================================
-- TABLA 5: photo_reports (REPORTES FOTOGRÁFICOS CON UBICACIÓN)
-- =========================================================================
-- Almacena fotos de usuarios con su ubicación geográfica exacta.
-- Las fotos se guardan como base64 en la BD para simplificar deployment.
CREATE TABLE IF NOT EXISTS photo_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,      -- Identificador único del reporte
    username TEXT NOT NULL,                    -- Usuario que subió la foto
    latitude REAL NOT NULL,                    -- Ubicación exacta (latitud)
    longitude REAL NOT NULL,                   -- Ubicación exacta (longitud)
    photo_data TEXT NOT NULL,                  -- Imagen en base64
    description TEXT,                          -- Descripción opcional del usuario
    status TEXT DEFAULT 'new',                 -- Estado: 'new' (nuevo), 'reviewed' (revisado), 'resolved' (resuelto)
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP -- Cuándo se subió
);