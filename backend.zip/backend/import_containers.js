const fs = require('fs');
const { execSync } = require('child_process');

// Leer el GeoJSON del frontend
const geojsonRaw = fs.readFileSync('../frontend/contenedores.geojson');
const geojson = JSON.parse(geojsonRaw);

let values = [];
let count = 1;

geojson.features.forEach(feature => {
    if (feature.geometry && feature.geometry.type === 'Point') {
        const lng = feature.geometry.coordinates[0];
        const lat = feature.geometry.coordinates[1];
        const name = feature.properties.name || `Contenedor ${count}`;
        // Usa el nombre como ID, o genera uno basado en coordenadas
        const id = feature.properties.name || `BIN-${lat.toFixed(5)}-${lng.toFixed(5)}`;

        values.push(`('${id}', '${name}', ${lat}, ${lng})`);
        count++;
    }
});

if (values.length > 0) {
    // Crea la consulta SQL múltiple
    const sql = `INSERT INTO containers (id, name, lat, lng) VALUES\n${values.join(',\n')};`;
    fs.writeFileSync('seed.sql', sql);
    console.log(`Generado seed.sql con ${values.length} contenedores. Subiendo a Cloudflare D1...`);

    // Ejecutar el comando de wrangler automáticamente
    execSync('wrangler d1 execute soterrados_db --file=./seed.sql --remote', { stdio: 'inherit' });
    console.log("¡Contenedores insertados exitosamente!");
} else {
    console.log("No se encontraron puntos válidos en el archivo GeoJSON.");
}
