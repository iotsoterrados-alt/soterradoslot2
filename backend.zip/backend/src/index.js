/**
 * =========================================================================
 * BACKEND API SERVERLESS (CLOUDFLARE WORKERS) | VERSIÓN 12 DE ABRIL
 * =========================================================================
 * Este código es el "Cerebro" en la nube. Se ejecuta en los servidores Edge
 * de Cloudflare. Usa el framework 'Hono' que es súper ligero y rápido.
 */

import { Hono } from 'hono';
import { cors } from 'hono/cors';

const app = new Hono();
const liveSubscribers = new Set();

function broadcastLiveUpdate(payload) {
    const message = `event: telemetry\ndata: ${JSON.stringify(payload)}\n\n`;
    const encoded = new TextEncoder().encode(message);
    for (const controller of Array.from(liveSubscribers)) {
        try {
            controller.enqueue(encoded);
        } catch (error) {
            liveSubscribers.delete(controller);
        }
    }
}

async function ensureSchema(env) {
    const statements = [
        `CREATE TABLE IF NOT EXISTS containers (
            id TEXT PRIMARY KEY,
            name TEXT DEFAULT 'Contenedor Desconocido',
            lat REAL NOT NULL,
            lng REAL NOT NULL,
            address TEXT DEFAULT 'Dirección no registrada',
            photo_url TEXT,
            current_fill_level REAL DEFAULT 0,
            current_fill_sec1 REAL DEFAULT 0,
            current_fill_sec2 REAL DEFAULT 0,
            current_fill_sec3 REAL DEFAULT 0,
            last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS readings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            container_id TEXT NOT NULL,
            sec1 REAL NOT NULL,
            sec2 REAL NOT NULL,
            sec3 REAL NOT NULL,
            average_fill REAL NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS emptying_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            container_id TEXT NOT NULL,
            level_before REAL NOT NULL,
            level_after REAL NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS users (
            email TEXT PRIMARY KEY,
            name TEXT,
            picture TEXT,
            role TEXT DEFAULT 'user',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS photo_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            photo_data TEXT NOT NULL,
            description TEXT,
            status TEXT DEFAULT 'new',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`
    ];

    for (const sql of statements) {
        await env.DB.prepare(sql).run();
    }

    await env.DB.prepare("INSERT OR IGNORE INTO users (email, name, role) VALUES (?, ?, ?)").bind('iotsoterrados@gmail.com', 'Admin Principal', 'admin').run();

    const existing = await env.DB.prepare("SELECT COUNT(*) as count FROM containers").first();
    if (!existing || Number(existing.count) === 0) {
        await env.DB.prepare("INSERT OR IGNORE INTO containers (id, name, lat, lng) VALUES (?, ?, ?, ?)").bind('BIN-001', 'Contenedor Demo 1', -10.6832, -76.2574).run();
        await env.DB.prepare("INSERT OR IGNORE INTO containers (id, name, lat, lng) VALUES (?, ?, ?, ?)").bind('BIN-002', 'Contenedor Demo 2', -10.6867, -76.2458).run();
        await env.DB.prepare("INSERT OR IGNORE INTO containers (id, name, lat, lng) VALUES (?, ?, ?, ?)").bind('BIN-003', 'Contenedor Demo 3', -10.6807, -76.2545).run();
    }
}

app.use('/*', async (c, next) => {
    if (c.env?.DB) {
        await ensureSchema(c.env);
    }
    await next();
});

// 🛡️ CORS EXPLICITO: Permite que el navegador envíe las cabeceras de Autorización sin bloquearlas
app.use('/*', cors({ 
    origin: ['https://soterradosundac.com', 'https://soterrados-iot-frontend.pages.dev', 'http://localhost:5500', 'http://127.0.0.1:5500', 'http://127.0.0.1:8787'],
    allowHeaders: ['Content-Type', 'Authorization', 'X-IoT-Secret', 'X-Local-Admin-Token']
}));

const IOT_SECRET = "Soterrados_IoT_Secret_Key_2026"; 

// 🛡️ DECODIFICADOR ROBUSTO: Ahora repara matemáticamente los tokens de Google antes de leerlos
function decodeGoogleJWT(token) {
    try {
        const base64Url = token.split('.')[1];
        let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        // Agrega el "Padding" (relleno) necesario para que V8/Cloudflare no falle al decodificar
        while (base64.length % 4) {
            base64 += '=';
        }
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''));
        return JSON.parse(jsonPayload);
    } catch (e) {
        return null;
    }
}

// 🛡️ VALIDADOR DE DIAGNÓSTICO: Ahora nos dirá exactamente DÓNDE falla
async function requireAdmin(c) {
    const authHeader = c.req.header('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) return { authorized: false, reason: "Cabecera de token faltante" };
    
    const token = authHeader.split(' ')[1];
    const payload = decodeGoogleJWT(token);
    if (!payload || !payload.email) return { authorized: false, reason: "Token ilegible o corrupto" };

    const user = await c.env.DB.prepare("SELECT role FROM users WHERE email = ?").bind(payload.email).first();
    if (!user) return { authorized: false, reason: "Usuario no existe en la BD" };
    if (user.role !== 'admin') return { authorized: false, reason: "El rol en la BD no es admin" };

    return { authorized: true };
}

async function requireAdminOrLocal(c) {
    const authHeader = c.req.header('Authorization');
    if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.split(' ')[1];
        const payload = decodeGoogleJWT(token);
        if (payload?.email) {
            const user = await c.env.DB.prepare("SELECT role FROM users WHERE email = ?").bind(payload.email).first();
            if (user?.role === 'admin') return { authorized: true };
        }
    }

    const localToken = c.req.header('X-Local-Admin-Token');
    if (localToken === 'local-admin-token') {
        return { authorized: true };
    }

    return { authorized: false, reason: 'Se requiere token admin válido' };
}

function clamp(value, min = 0, max = 100) {
    return Math.max(min, Math.min(max, value));
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function simulateTelemetryForContainer(env, container) {
    const db = env.DB;
    let sec1 = Number(container.current_fill_sec1 || 0);
    let sec2 = Number(container.current_fill_sec2 || 0);
    let sec3 = Number(container.current_fill_sec3 || 0);
    let vaciado = false;
    const averageFill = (sec1 + sec2 + sec3) / 3;

    if (averageFill > 90 && Math.random() > 0.7) {
        sec1 = randomInt(0, 10);
        sec2 = randomInt(0, 10);
        sec3 = randomInt(0, 10);
        vaciado = true;
    } else {
        sec1 = clamp(sec1 + randomInt(2, 8));
        sec2 = clamp(sec2 + randomInt(2, 8));
        sec3 = clamp(sec3 + randomInt(2, 8));
    }

    const finalAverage = Math.round((sec1 + sec2 + sec3) / 3);
    await db.prepare("INSERT INTO readings (container_id, sec1, sec2, sec3, average_fill) VALUES (?, ?, ?, ?, ?)").bind(container.id, sec1, sec2, sec3, finalAverage).run();
    await db.prepare("UPDATE containers SET current_fill_level=?, current_fill_sec1=?, current_fill_sec2=?, current_fill_sec3=?, last_updated=CURRENT_TIMESTAMP WHERE id=?").bind(finalAverage, sec1, sec2, sec3, container.id).run();

    const telemetryPayload = {
        type: 'telemetry',
        containerId: container.id,
        sec1,
        sec2,
        sec3,
        averageFill: finalAverage,
        vaciado,
        timestamp: new Date().toISOString()
    };
    broadcastLiveUpdate(telemetryPayload);
    return { containerId: container.id, sec1, sec2, sec3, averageFill: finalAverage, vaciado };
}

// =====================================================================
// RUTAS DE USUARIOS
// =====================================================================
app.post('/api/auth/google', async (c) => {
    const db = c.env.DB;
    const body = await c.req.json();
    const { email, name, picture } = decodeGoogleJWT(body.token) || {};
    if (!email) return c.json({ success: false, error: "Token inválido" }, 401);

    let user = await db.prepare("SELECT * FROM users WHERE email = ?").bind(email).first();
    
    if (!user) {
        await db.prepare("INSERT INTO users (email, name, picture, role) VALUES (?, ?, ?, 'user')").bind(email, name, picture).run();
        user = { email, name, picture, role: 'user' };
    } else {
        await db.prepare("UPDATE users SET name = ?, picture = ? WHERE email = ?").bind(name, picture, email).run();
        user.name = name;
        user.picture = picture;
    }
    
    return c.json({ success: true, user });
});

// Ruta protegida con Diagnóstico
app.post('/api/users/upgrade', async (c) => {
    const adminCheck = await requireAdmin(c);
    if (!adminCheck.authorized) return c.json({ success: false, error: `Acceso denegado. Razón: ${adminCheck.reason}` }, 403);

    const db = c.env.DB;
    const { email_to_upgrade } = await c.req.json();
    const result = await db.prepare("UPDATE users SET role = 'admin' WHERE email = ?").bind(email_to_upgrade).run();
    if (result.meta && result.meta.changes > 0) return c.json({ success: true, message: `Usuario actualizado.` });
    return c.json({ success: false, error: "Usuario no existe." }, 400);
});

// =====================================================================
// RUTAS IOT Y CONTENEDORES
// =====================================================================
async function handleTelemetry(c, body) {
    const secret = c.req.header('X-IoT-Secret') || body.secret || body.apiKey;
    if (secret !== IOT_SECRET) return c.json({ success: false, error: 'Hardware no autorizado.' }, 401);

    const db = c.env.DB;
    const payload = body.payload && typeof body.payload === 'object' ? body.payload : body;
    const deviceId = payload.deviceId || body.deviceId || payload.device_id || body.device_id;
    const containerId = payload.containerId || body.containerId || payload.container_id || body.container_id || body.id;
    const deviceToContainerId = {
        '12': 'BIN--10.68312--76.24373'
    };
    const resolvedContainerId = containerId || (deviceId && deviceToContainerId[String(deviceId)]);
    const sec1 = Number(payload.sec1 ?? payload.s1 ?? payload.sensor1 ?? body.sec1 ?? body.s1 ?? body.sensor1 ?? 0);
    const sec2 = Number(payload.sec2 ?? payload.s2 ?? payload.sensor2 ?? body.sec2 ?? body.s2 ?? body.sensor2 ?? 0);
    const sec3 = Number(payload.sec3 ?? payload.s3 ?? payload.sensor3 ?? body.sec3 ?? body.s3 ?? body.sensor3 ?? 0);

    if (!resolvedContainerId) return c.json({ success: false, error: 'Falta el identificador del contenedor.' }, 400);

    const averageFill = Math.round((sec1 + sec2 + sec3) / 3);

    const container = await db.prepare("SELECT * FROM containers WHERE id = ?").bind(resolvedContainerId).first();
    if (!container) return c.json({ success: false, error: 'Contenedor no registrado.' }, 404);

    const previousLevel = container.current_fill_level || 0;
    let vaciado = false;

    if (previousLevel > 70 && averageFill < 15) {
        await db.prepare("INSERT INTO emptying_events (container_id, level_before, level_after) VALUES (?, ?, ?)").bind(resolvedContainerId, previousLevel, averageFill).run();
        vaciado = true;
    }

    await db.prepare("INSERT INTO readings (container_id, sec1, sec2, sec3, average_fill) VALUES (?, ?, ?, ?, ?)").bind(resolvedContainerId, sec1, sec2, sec3, averageFill).run();
    await db.prepare(`UPDATE containers SET current_fill_level=?, current_fill_sec1=?, current_fill_sec2=?, current_fill_sec3=?, last_updated=CURRENT_TIMESTAMP WHERE id=?`).bind(averageFill, sec1, sec2, sec3, resolvedContainerId).run();

    const telemetryPayload = {
        type: 'telemetry',
        containerId: resolvedContainerId,
        sec1,
        sec2,
        sec3,
        averageFill,
        vaciado,
        timestamp: new Date().toISOString()
    };
    broadcastLiveUpdate(telemetryPayload);

    return c.json({ success: true, vaciado, averageFill, containerId });
}

app.post('/api/readings', async (c) => {
    let body = {};
    try { body = await c.req.json(); } catch (error) { body = {}; }
    return handleTelemetry(c, body);
});

app.post('/api/device/telemetry', async (c) => {
    let body = {};
    try { body = await c.req.json(); } catch (error) { body = {}; }
    return handleTelemetry(c, body);
});

app.get('/api/containers', async (c) => {
    const { results } = await c.env.DB.prepare("SELECT * FROM containers").all();
    return c.json(results);
});

app.get('/api/events/stream', (c) => {
    const encoder = new TextEncoder();
    let closed = false;
    let controllerRef = null;

    const stream = new ReadableStream({
        start(controller) {
            controllerRef = controller;
            liveSubscribers.add(controller);
            controller.enqueue(encoder.encode('event: connected\ndata: {"status":"ok"}\n\n'));

            const heartbeat = setInterval(() => {
                if (closed) return;
                try {
                    controller.enqueue(encoder.encode(': ping\n\n'));
                } catch (error) {
                    closed = true;
                    clearInterval(heartbeat);
                    liveSubscribers.delete(controller);
                }
            }, 15000);

            if (c.req.raw && typeof c.req.raw.signal?.addEventListener === 'function') {
                c.req.raw.signal.addEventListener('abort', () => {
                    if (closed) return;
                    closed = true;
                    clearInterval(heartbeat);
                    liveSubscribers.delete(controller);
                }, { once: true });
            }
        },
        cancel() {
            closed = true;
            if (controllerRef) {
                liveSubscribers.delete(controllerRef);
            }
        }
    });

    return new Response(stream, {
        headers: {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no'
        }
    });
});

app.get('/api/stats', async (c) => {
    const containersResult = await c.env.DB.prepare("SELECT * FROM containers").all();
    const containers = containersResult.results;
    const critical = containers.filter(cont => (cont.current_fill_level || 0) > 80).length;
    const eventsResult = await c.env.DB.prepare("SELECT COUNT(*) as count FROM emptying_events WHERE timestamp >= datetime('now', '-1 day')").first();
    
    return c.json({ total: containers.length, critical, emptiesToday: eventsResult ? eventsResult.count : 0 });
});

// Ruta protegida con Diagnóstico
app.post('/api/containers/update-info', async (c) => {
    const adminCheck = await requireAdmin(c);
    if (!adminCheck.authorized) return c.json({ success: false, error: `Acceso denegado. Razón: ${adminCheck.reason}` }, 403);

    const db = c.env.DB;
    const { id, address, photoUrl } = await c.req.json();
    const result = await db.prepare("UPDATE containers SET address = ?, photo_url = ? WHERE id = ?").bind(address, photoUrl, id).run();
                           
    if (result.meta && result.meta.changes > 0) return c.json({ success: true, message: "Actualizado correctamente." });
    return c.json({ success: false, error: "Error al actualizar." }, 400);
});

app.post('/api/simulator/run', async (c) => {
    const secret = c.req.header('X-IoT-Secret');
    const localToken = c.req.header('X-Local-Admin-Token');
    const authHeader = c.req.header('Authorization');
    let authorized = false;

    if (secret === IOT_SECRET || localToken === 'local-admin-token') {
        authorized = true;
    }

    if (!authorized && authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.split(' ')[1];
        const payload = decodeGoogleJWT(token);
        if (payload?.email) {
            const user = await c.env.DB.prepare("SELECT role FROM users WHERE email = ?").bind(payload.email).first();
            if (user?.role === 'admin') authorized = true;
        }
    }

    if (!authorized) {
        return c.json({ success: false, error: 'Acceso denegado. Se requiere token o clave válida.' }, 403);
    }

    const db = c.env.DB;
    const count = Math.max(1, Math.min(10, Number(c.req.query('count') || 3)));
    const containersResult = await db.prepare("SELECT id, current_fill_sec1, current_fill_sec2, current_fill_sec3 FROM containers").all();
    const containers = containersResult.results || [];
    if (!containers.length) {
        return c.json({ success: false, error: 'No hay contenedores para simular.' }, 400);
    }

    const shuffled = containers.sort(() => 0.5 - Math.random()).slice(0, Math.min(count, containers.length));
    const simulated = [];
    for (const container of shuffled) {
        simulated.push(await simulateTelemetryForContainer(c.env, container));
    }

    return c.json({ success: true, simulated });
});

// =====================================================================
// RUTAS DE REPORTES FOTOGRÁFICOS
// =====================================================================

// Subir una foto con geolocalización
app.post('/api/photo-reports', async (c) => {
    const db = c.env.DB;
    try {
        const body = await c.req.json();
        const { username, latitude, longitude, photoBase64, description } = body;

        if (!username || latitude === undefined || longitude === undefined || !photoBase64) {
            return c.json({ success: false, error: "Faltan campos obligatorios" }, 400);
        }

        const result = await db.prepare(
            "INSERT INTO photo_reports (username, latitude, longitude, photo_data, description, status) VALUES (?, ?, ?, ?, ?, 'new')"
        ).bind(username, latitude, longitude, photoBase64, description || '').run();

        return c.json({ success: true, id: result.meta.last_row_id, message: "Foto subida exitosamente" });
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

// Obtener todos los reportes fotográficos
app.get('/api/photo-reports', async (c) => {
    const db = c.env.DB;
    try {
        const requestedStatus = c.req.query('status');
        let sql = "SELECT id, username, latitude, longitude, description, status, photo_data, created_at FROM photo_reports";
        let params = [];

        if (requestedStatus === 'approved') {
            sql += " WHERE status = 'approved'";
        } else if (requestedStatus === 'pending') {
            const adminCheck = await requireAdminOrLocal(c);
            if (!adminCheck.authorized) return c.json({ success: false, error: `Acceso denegado. Razón: ${adminCheck.reason}` }, 403);
            sql += " WHERE status = 'new'";
        } else if (requestedStatus === 'all') {
            const adminCheck = await requireAdminOrLocal(c);
            if (!adminCheck.authorized) return c.json({ success: false, error: `Acceso denegado. Razón: ${adminCheck.reason}` }, 403);
        } else {
            sql += " WHERE status = 'approved'";
        }

        sql += " ORDER BY created_at DESC LIMIT 100";
        const result = await db.prepare(sql).bind(...params).all();
        return c.json({ success: true, reports: result.results || [] });
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

// Obtener una foto específica (datos completos incluyendo base64)
app.get('/api/photo-reports/:id', async (c) => {
    const db = c.env.DB;
    const id = c.req.param('id');
    try {
        const result = await db.prepare("SELECT * FROM photo_reports WHERE id = ?").bind(id).first();
        if (!result) return c.json({ success: false, error: "Foto no encontrada" }, 404);
        return c.json({ success: true, report: result });
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

app.post('/api/photo-reports/:id/archive', async (c) => {
    const adminCheck = await requireAdminOrLocal(c);
    if (!adminCheck.authorized) return c.json({ success: false, error: `Acceso denegado. Razón: ${adminCheck.reason}` }, 403);

    const db = c.env.DB;
    const id = c.req.param('id');
    try {
        const result = await db.prepare("UPDATE photo_reports SET status = 'resolved' WHERE id = ?").bind(id).run();
        if (result.meta && result.meta.changes > 0) {
            return c.json({ success: true, message: 'Reporte archivado como recolector pasado.' });
        }
        return c.json({ success: false, error: 'Reporte no encontrado o ya archivado.' }, 404);
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

app.post('/api/photo-reports/:id/approve', async (c) => {
    const adminCheck = await requireAdminOrLocal(c);
    if (!adminCheck.authorized) return c.json({ success: false, error: `Acceso denegado. Razón: ${adminCheck.reason}` }, 403);

    const db = c.env.DB;
    const id = c.req.param('id');
    try {
        const result = await db.prepare("UPDATE photo_reports SET status = 'approved' WHERE id = ?").bind(id).run();
        if (result.meta && result.meta.changes > 0) {
            return c.json({ success: true, message: 'Reporte aprobado y visible en el mapa.' });
        }
        return c.json({ success: false, error: 'Reporte no encontrado o ya aprobado.' }, 404);
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

app.delete('/api/photo-reports/:id', async (c) => {
    const adminCheck = await requireAdminOrLocal(c);
    if (!adminCheck.authorized) return c.json({ success: false, error: `Acceso denegado. Razón: ${adminCheck.reason}` }, 403);

    const db = c.env.DB;
    const id = c.req.param('id');
    try {
        const result = await db.prepare("DELETE FROM photo_reports WHERE id = ?").bind(id).run();
        if (result.meta && result.meta.changes > 0) {
            return c.json({ success: true, message: 'Reporte eliminado correctamente.' });
        }
        return c.json({ success: false, error: 'Reporte no encontrado.' }, 404);
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

export default {
    fetch: app.fetch,
    async scheduled(event, env, ctx) {
        await env.DB.prepare("DELETE FROM readings WHERE timestamp < datetime('now', '-2 hours')").run();
    }
};